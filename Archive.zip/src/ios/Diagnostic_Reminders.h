/*
 *  Diagnostic_Reminders.h
 *  Diagnostic Plugin - Reminders Module
 *
 *  Copyright (c) 2018 Working Edge Ltd.
 *  Copyright (c) 2012 AVANTIC ESTUDIO DE INGENIEROS
 */

#import <Cordova/CDV.h>
#import <Cordova/CDVPlugin.h>
#import "Diagnostic.h"

#import <EventKit/EventKit.h>


@interface Diagnostic_Reminders : CDVPlugin

@property (nonatomic) EKEventStore *eventStore;

- (void) getRemindersAuthorizationStatus: (CDVInvokedUrlCommand*)command;
- (void) isRemindersAuthorized: (CDVInvokedUrlCommand*)command;
- (void) requestRemindersAuthorization: (CDVInvokedUrlCommand*)command;

@end
